<?php
$host = 'localhost';
$user = 'root';
$password = '';
$dbname = 'dbmahasiswa';

$koneksi = mysqli_connect($host,$user,$password,$dbname);
?>